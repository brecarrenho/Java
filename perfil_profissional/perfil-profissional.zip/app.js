document.getElementById('contateBtn').addEventListener('click', function() {
    alert('Obrigado por entrar em contato!');
});
